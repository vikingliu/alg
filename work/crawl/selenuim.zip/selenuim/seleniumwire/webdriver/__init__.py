from selenium.webdriver import *  # noqa

from .browser import Chrome, Edge, Firefox, Safari  # noqa
